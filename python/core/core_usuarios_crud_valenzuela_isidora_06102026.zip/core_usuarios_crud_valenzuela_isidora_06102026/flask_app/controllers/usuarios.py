from flask_app import app
from flask import render_template, request, redirect, url_for
from flask_app.models.usuario import Usuario

@app.route("/")
def index():
    return redirect(url_for("usuarios"))

@app.route("/usuarios")
def usuarios():
    lista_usuarios = Usuario.get_all()
    return render_template("index.html", usuarios=lista_usuarios)

@app.route("/usuarios/nuevo")
def nuevo():
    return render_template("nuevo.html")

@app.route("/usuarios/crear", methods=["POST"])
def crear():
    data = {
        "nombre": request.form["nombre"].strip(),
        "apellido": request.form["apellido"].strip(),
        "email": request.form["email"].strip()
    }
    Usuario.save(data)
    return redirect(url_for("usuarios"))

@app.route("/usuarios/<int:id>")
def detalle(id):
    usuario = Usuario.get_by_id(id)
    return render_template("detalle.html", usuario=usuario)

@app.route("/usuarios/editar/<int:id>")
def editar(id):
    usuario = Usuario.get_by_id(id)
    return render_template("editar.html", usuario=usuario)

@app.route("/usuarios/<int:id>/actualizar", methods=["POST"])
def actualizar(id):
    data = {
        "id": id,
        "nombre": request.form["nombre"].strip(),
        "apellido": request.form["apellido"].strip(),
        "email": request.form["email"].strip()
    }
    Usuario.update(data)
    return redirect(url_for("usuarios"))

@app.route("/usuarios/borrar/<int:id>")
def borrar(id):
    Usuario.delete({"id": id})
    return redirect(url_for("usuarios"))